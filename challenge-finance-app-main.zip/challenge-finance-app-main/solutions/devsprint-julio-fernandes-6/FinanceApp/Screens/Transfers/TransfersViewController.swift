//
//  TransfersViewController.swift
//  FinanceApp
//
//  Created by Rodrigo Borges on 30/12/21.
//

import UIKit

class TransfersViewController: UIViewController {

    override func loadView() {
        self.view = TransfersView()
        self.view.backgroundColor = .white
    }
}
