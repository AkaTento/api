//
//  HomeModel.swift
//  FinanceApp
//
//  Created by Rodrigo Borges on 04/02/22.
//

import Foundation

struct HomeModel: Decodable {

}
