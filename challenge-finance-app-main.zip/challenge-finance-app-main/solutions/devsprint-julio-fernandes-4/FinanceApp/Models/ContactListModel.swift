//
//  ContactListEntity.swift
//  FinanceApp
//
//  Created by Rodrigo Francischett Occhiuto on 24/06/22.
//

import Foundation

struct ContactListModel: Decodable {
    let name: String
    let phone: String
}
