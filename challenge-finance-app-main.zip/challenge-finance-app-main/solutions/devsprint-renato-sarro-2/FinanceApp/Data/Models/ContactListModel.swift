//
//  Contact.swift
//  FinanceApp
//
//  Created by Bruno Guirra on 22/03/22.
//

import Foundation

struct Contact: Decodable {
    let name: String
    let phone: String
}

