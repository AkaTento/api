//
//  TransfersModel.swift
//  FinanceApp
//
//  Created by Gilmar Junior on 22/03/22.
//

import Foundation

struct TransferResult: Decodable{
    let success: Bool
}
