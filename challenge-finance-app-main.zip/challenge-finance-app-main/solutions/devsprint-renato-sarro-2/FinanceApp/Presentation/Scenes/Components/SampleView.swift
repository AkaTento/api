//
//  SampleView.swift
//  FinanceApp
//
//  Created by Rodrigo Borges on 09/03/22.
//

import UIKit

class SampleView: UIView {
    
}
